module.exports = {
  ENV_MODE: 'auto',
  API_ENDPOINTS: {
    NARRANS_API: 'https://api-se-dev.narrans.samsungds.net/v1/chat/completions',
    LLAMA4_API: 'http://apigw-stg.samsungds.net:8000/llama4/1/llama/aiserving/llama-4/maverick/v1/chat/completions',
    LLAMA4_MAVERICK_API: 'http://apigw-stg.samsungds.net:8000/llama4/1/llama/aiserving/llama-4/maverick/v1/chat/completions',
    LLAMA4_SCOUT_API: 'http://apigw-stg.samsungds.net:8000/llama4/1/llama/aiserving/llama-4/scout/v1/chat/completions',
    OPENROUTER_API: 'https://openrouter.ai/api/v1/chat/completions',
    SWDP_API: 'http://swdp-api-dev.samsungds.net/api/v1',
    JIRA_API: 'http://jira-api.samsungds.net/rest/api/latest',
    BITBUCKET_API: 'http://bitbucket-api.samsungds.net/rest/api/latest'
  },
  API_KEYS: {
    OPENROUTER_API_KEY: '',
    NARRANS_API_KEY: '',
    LLAMA4_API_KEY: ''
  },
  DEFAULT_MODEL: 'gemini-2.5-flash',
  AVAILABLE_MODELS: [
    {
      id: 'narrans',
      name: 'NARRANS',
      provider: 'custom',
      apiUrl: 'https://api-se-dev.narrans.samsungds.net/v1/chat/completions',
      contextWindow: 10000,
      maxTokens: 10000,
      temperature: 0
    },
    {
      id: 'llama-4-maverick',
      name: 'Llama 4 Maverick',
      provider: 'custom',
      apiUrl: 'http://apigw-stg.samsungds.net:8000/llama4/1/llama/aiserving/llama-4/maverick/v1/chat/completions',
      contextWindow: 50000,
      maxTokens: 50000,
      temperature: 0
    },
    {
      id: 'llama-4-scout',
      name: 'Llama 4 Scout',
      provider: 'custom',
      apiUrl: 'http://apigw-stg.samsungds.net:8000/llama4/1/llama/aiserving/llama-4/scout/v1/chat/completions',
      contextWindow: 50000,
      maxTokens: 50000,
      temperature: 0
    },
    {
      id: 'gemini-2.5-flash',
      name: 'Google Gemini 2.5 Flash',
      provider: 'openrouter',
      apiUrl: 'https://openrouter.ai/api/v1/chat/completions',
      apiModel: 'google/gemini-2.5-flash-preview',
      contextWindow: 32000,
      maxTokens: 8192,
      temperature: 0.7
    },
    {
      id: 'phi-4-reasoning-plus',
      name: 'Microsoft Phi-4',
      provider: 'openrouter',
      apiUrl: 'https://openrouter.ai/api/v1/chat/completions',
      apiModel: 'microsoft/phi-4-reasoning-plus',
      contextWindow: 32000,
      maxTokens: 8192,
      temperature: 0.7
    },
    {
      id: 'local',
      name: '로컬 시뮬레이션',
      provider: 'local',
      temperature: 0.7
    }
  ],
  USE_MOCK_DATA: false,
  FORCE_SSL_BYPASS: true
};